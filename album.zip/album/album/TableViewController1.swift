//
//  TableViewController1.swift
//  album
//
//  Created by nju on 2021/12/21.
//

import UIKit
import CoreML
import Vision

class TableViewController1: UITableViewController {
    
    var groups:[String]=[
        "apple",
        "banana",
        "cake",
        "candy",
        "carrot",
        "cookie",
        "doughnut",
        "grape",
        "hot dog",
        "ice cream",
        "juice",
        "muffin",
        "orange",
        "pineapple",
        "popcorn",
        "pretzel",
        "salad",
        "strawberry",
        "waffle",
        "watermelon"
    ]
    var groupphoto:[String:[UIImage?]]=[
        "apple":[UIImage(named:"apple1.jpeg"),UIImage(named:"apple2.jpeg"),UIImage(named:"apple3.jpeg")],
        "banana":[UIImage(named:"banana1.jpeg"),UIImage(named:"banana2.jpeg")],
        "cake":[],
        "candy":[],
        "carrot":[],
        "cookie":[],
        "doughnut":[],
        "grape":[],
        "hot dog":[],
        "ice cream":[],
        "juice":[],
        "muffin":[],
        "orange":[],
        "pineapple":[],
        "popcorn":[],
        "pretzel":[],
        "salad":[],
        "strawberry":[],
        "waffle":[],
        "watermelon":[]
    ]
    var photos:[UIImage]=[]
    
    var photo1:UIImage?
    
    
    lazy var classificationRequest: VNCoreMLRequest = {
        do{
            let classifier = try snacks(configuration: MLModelConfiguration())
            let model = try VNCoreMLModel(for: classifier.model)
            let request = VNCoreMLRequest(model:model,completionHandler: {
                [weak self]request,error in
                self?.processObservations(for:request,error:error)
            })
            request.imageCropAndScaleOption = .centerCrop
            return request
        }catch{
            fatalError("Failed to create request")
        }
    }()
    
    func processObservations(for request:VNRequest,error:Error?){
        if let results=request.results as? [VNClassificationObservation]{
            if results.isEmpty{
                return
            }else{
                let result = results[0].identifier
                let confidence = results[0].confidence
                if confidence>0.6{
                    groupphoto[result]?.append(photo1)
                }
            }
        }else {
            print("error")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        self.navigationController?.navigationBar.prefersLargeTitles=true
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 20
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "group", for: indexPath) as! TableViewCell1
        let group = groups[indexPath.row]
        cell.title.text!=group
        // Configure the cell...

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier=="group"{
            let groupViewController=segue.destination as! TableViewController2
            let cell=sender as! TableViewCell1
            groupViewController.photos2=self.groupphoto[cell.title.text!]
        }
    }
}

extension TableViewController1:Choose{
    func choose(photo: UIImage?) {
        self.photo1=photo
        print(1111)
        self.groupphoto["apple"]!.append(photo)
    }
}
