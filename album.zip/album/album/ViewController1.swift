//
//  viewViewController1.swift
//  album
//
//  Created by nju on 2021/12/21.
//

import UIKit

protocol Choose{
    func choose(photo:UIImage?)
}

class ViewController1: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imagePicker.delegate = self
        // Do any additional setup after loading the view.
    }
    var chooseDelegate:Choose?
    var photoChoosed:UIImage?
    
    @IBAction func camera(_ sender: Any) {
        openCamera()
    }
    @IBAction func photolibrary(_ sender: Any) {
        openPhoto()
    }
    @IBAction func done(_ sender: Any) {
        self.chooseDelegate?.choose(photo:photoChoosed)
        self.dismiss(animated: true, completion: nil)
    }
    func openCamera(){
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera){
            imagePicker.sourceType = UIImagePickerController.SourceType.camera;
            imagePicker.allowsEditing = true
            self.present(imagePicker,animated:true,completion:nil)
        }
    }
    
    func openPhoto(){
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
            imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker,animated:true,completion:nil)
            self.chooseDelegate?.choose(photo:photoChoosed)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageView.image = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        photoChoosed=imageView.image
        self.dismiss(animated:true,completion: nil)
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier=="done"{
            var doneViewController=segue.destination as! TableViewController1
            doneViewController.photo1=photoChoosed
            print(3333)
        }
    }
    

}
